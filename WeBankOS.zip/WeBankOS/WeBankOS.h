#pragma once

#include "FileGroup.h"

class WeBankOS {
public:
	void run();
};

