#pragma once

#include "FileGroup.h"

using namespace std;

class ICCard {
private:
	string account;
	string host;
	string TEL;
	string password;
	double balance;
};

