﻿#include <iostream>
#include "WeBankOS.h"


void WeBankOS::run() {}
