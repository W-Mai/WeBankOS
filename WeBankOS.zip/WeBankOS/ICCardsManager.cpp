#include "ICCardsManager.h"

void ICCardsManager::addCard(WeUser& usr, string password) {}

void ICCardsManager::delCard(ICCard& card) {}

void ICCardsManager::searchCard(AccountType account) {}
