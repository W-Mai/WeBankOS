#pragma once

#include <string>
#include <vector>

using namespace std;

typedef string AccountType;

class WeUser;
class ICCard;

class UserManager;
class ICCardsManager;
class FileManager;
class FundsManager;

class WeBankOS;