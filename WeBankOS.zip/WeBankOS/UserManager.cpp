#include "UserManager.h"

WeUser* UserManager::searchUser(string ID) {
	// TODO: �ڴ˴����� return ���
	return nullptr;
}

bool UserManager::registerUser(WeUser* usr) {
	return false;
}

bool UserManager::registerUser(string name, string ID, bool gender, string age, string TEL) {
	return false;
}

bool UserManager::cancelUser(WeUser* usr) {
	return false;
}

bool UserManager::cancelUser(string ID) {
	return false;
}

WeUser* UserManager::verifyUser(string name, string password) {
	// TODO: �ڴ˴����� return ���
	return nullptr;
}

