#pragma once

#include "FileGroup.h"

class FileManager {
	
};

